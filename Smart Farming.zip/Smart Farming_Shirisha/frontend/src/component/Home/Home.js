import { Link } from "react-router-dom";
import bg from '../../images/Background.jpeg';

const Home = () => {
  return (
    <div className="h-screen flex flex-col justify-center items-center bg-gray-100" 
    style={{ 
      backgroundImage: `url(${bg})`, 
      backgroundSize: "cover", 
      backgroundPosition: "center" 
    }}
    
    >
      <div className="bg-white bg-opacity-50 rounded-lg p-8 shadow-xl flex flex-col items-center">
        <div className="text-4xl font-bold mb-4">SMART FARMING</div>
        <div className="text-xl mb-8">Your Product Our Market</div>
        <div className="flex gap-16">
          <Link to="/login">
            <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">Login</button>
          </Link>
          <Link to='/products'>
            <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded">Product</button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
