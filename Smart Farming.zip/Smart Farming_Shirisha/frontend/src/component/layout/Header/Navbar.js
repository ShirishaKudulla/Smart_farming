import { IoHomeOutline } from "react-icons/io5";
import { FaUserLock } from "react-icons/fa6";
import { IoNewspaperOutline } from "react-icons/io5";
import { MdOutlineProductionQuantityLimits } from "react-icons/md";

import {Link} from 'react-router-dom'

const NavBar = () => {
  return (
    <nav className="bg-gray-800 text-white py-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex gap-10">
          <Link to='/'>
          <p className="text-md  flex items-center">
            <IoHomeOutline className="mr-2" size={25} />
            Home
          </p>
          </Link>
        
          <Link to='/products'>
          <p className="text-md  flex items-center">
            <MdOutlineProductionQuantityLimits className="mr-2" size={25} />
           PRODUCT
          </p></Link>
         
          <Link to='/login'>
          <p className="text-md  flex items-center">
            <FaUserLock className="mr-2" size={25} />
           LOGIN
          </p>
          </Link>
        
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
    