import NavBar from "./Navbar";
import { PiPlantThin } from "react-icons/pi";


const Header = () => {
    return (
      <>
        <header className="bg-gray-800 text-white shadow-md" >
          <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <div className="flex items-center">
                <span className="text-2xl font-bold ml-2">
                  <p className="text-md  flex items-center p-4">
                    <PiPlantThin  className="mr-2" size={50}/> SMART FARMING
                  </p>
                </span>
              </div>
              <div>
                <NavBar/> 
              </div>
            </div>
          </div>
        </header>
      </>
    );
};

export default Header;
