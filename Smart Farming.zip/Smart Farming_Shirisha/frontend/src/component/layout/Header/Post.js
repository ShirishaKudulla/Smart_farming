

const Post = ({ title, author, date, content }) => {
  return (
    <div className="max-w-2xl mx-auto bg-white shadow-md rounded-lg overflow-hidden">
      <div className="px-6 py-4">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{title}</h2>
        <p className="text-sm text-gray-600">By <span className="font-semibold">{author}</span> on <span className="font-semibold">{date}</span></p>
      </div>
      <div className="px-6 py-4">
        <p className="text-gray-700">{content}</p>
      </div>
    </div>
  );
};

export default Post;
